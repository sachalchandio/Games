package FinalProject;

import java.awt.BorderLayout;

import javax.swing.JFrame;

public class StartGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menue menu= new Menue();
		
	}

}
